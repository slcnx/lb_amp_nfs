ssh-keygen -t rsa -b 2048 -P '' -f ~/.ssh/id_rsa
# DNS
ssh-copy-id root@172.16.0.177
ssh-copy-id root@172.16.0.178

# HTTPD, PHP, MYSQL, ANSIBLE, Rsyslog
ssh-copy-id root@web1.magedu.com
ssh-copy-id root@web2.magedu.com
ssh-copy-id root@php.magedu.com
ssh-copy-id root@mysql.magedu.com
ssh-copy-id root@rsyslog.magedu.com
ssh-copy-id root@ansible.magedu.com
