[ -f ~/.ssh/id_rsa.pub ] || ssh-keygen -t rsa -b 2048 -P '' -f ~/.ssh/id_rsa
# HTTPD, PHP, MYSQL, ANSIBLE, Rsyslog
ssh-copy-id root@web1.magedu.com
ssh-copy-id root@web2.magedu.com
ssh-copy-id root@php.magedu.com
ssh-copy-id root@mysql.magedu.com
ssh-copy-id root@rsyslog.magedu.com
ssh-copy-id root@ansible.magedu.com
ssh-copy-id root@files.magedu.com
